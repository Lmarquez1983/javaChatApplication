package nc.prog1415.luismlab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telecom.InCallService;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        VideoView videoView = findViewById(R.id.video_view);
        String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.armaggedon_it;
        Uri uri = Uri.parse(videoPath);
        videoView.setVideoURI(uri);

        MediaController mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);
    }

    public void backBtn(View view){
        switch (view.getId()){
            case R.id.aboutBackIcon:
                startActivity(new Intent(AboutActivity.this,SettingsActivity.class));
                finish();
        }
    }
}