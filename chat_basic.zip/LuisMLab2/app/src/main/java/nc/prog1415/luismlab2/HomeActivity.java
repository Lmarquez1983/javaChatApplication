package nc.prog1415.luismlab2;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.Set;


public class HomeActivity extends AppCompatActivity {
    private Toolbar mTopToolbar;
    TextView enterName;
    private TextView playerName;
    private SwitchMaterial nightModeSwitch, notificationsSwitch, privateAcctSwitch;
    private SeekBar seekBar;
    private UserSettings settings;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mTopToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mTopToolbar);

        //settings = (UserSettings) getApplication();
        initWidgets();
        loadSharedPreferences();

        }

    private void loadSharedPreferences() {
        SharedPreferences darkMode = getSharedPreferences(UserSettings.NIGHTMODE, MODE_PRIVATE);
        SharedPreferences notifications = getSharedPreferences(UserSettings.NOTIFICATIONS, MODE_PRIVATE);
        SharedPreferences privateMode = getSharedPreferences(UserSettings.PRIVATEACCT, MODE_PRIVATE);


    }


    public void onDisplay(View view){
        enterName = (TextView) findViewById(R.id.playerName);

        String name = "Welcome " + enterName.getText().toString() + "!";
        Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
        intent.putExtra("keyname", name);
        startActivity(intent);
        Toast.makeText(HomeActivity.this, name, Toast.LENGTH_SHORT).show();
    }

    public void onDisplay2(View view){
        switch (view.getId()){
            case R.id.statsbtn:
                Toast.makeText(this,"Statistics is selected", Toast.LENGTH_SHORT).show();
                break;
            case R.id.profilebtn:
                Toast.makeText(this,"Profile is selected", Toast.LENGTH_SHORT).show();
                break;
            case R.id.networkbtn:
                Toast.makeText(this,"Network is selected", Toast.LENGTH_SHORT).show();
                break;
            case R.id.playbtn:
                Toast.makeText(this,"Play is selected", Toast.LENGTH_SHORT).show();
                break;

        }
    }

    public void initWidgets(){
        playerName = findViewById(R.id.playerName);
        nightModeSwitch = findViewById(R.id.nightModeSwitch);
        notificationsSwitch = findViewById(R.id.notificationSwitch);
        privateAcctSwitch = findViewById(R.id.privacySwitch);
        seekBar = findViewById(R.id.seekBar);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.notifications:
                Toast.makeText(this,"Notifications is selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item2:
                Toast.makeText(this,"Set Notifications is selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item3:
                Toast.makeText(this,"Report a Bug is selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item4:
                Toast.makeText(this,"Build a Team is selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item5:
                Toast.makeText(this,"Contribute is selected", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.item6:
                startActivity(new Intent(HomeActivity.this,SettingsActivity.class));
                finish();
                return true;

            case R.id.item7:
                startActivity(new Intent(HomeActivity.this,AboutActivity.class));
                finish();
                return true;

            default:return super.onOptionsItemSelected(item);
        }
    }




}

