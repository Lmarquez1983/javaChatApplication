package nc.prog1415.luismlab2;

import android.content.Context;
import android.content.Intent;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.ProgressBar;
import android.widget.TextView;

public class LoadingScreen extends Animation {
    private Context context;
    private ProgressBar progressBar;
    private TextView textView;
    private float start;
    private float end;

    public LoadingScreen(Context context, ProgressBar progressBar, TextView textView, float start, float end){
        this.context = context;
        this.progressBar = progressBar;
        this.textView = textView;
        this.start=start;
        this.end=end;
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        super.applyTransformation(interpolatedTime, t);
        float floatval = start + (end-start) * interpolatedTime;
        progressBar.setProgress((int)floatval);
        textView.setText((int)floatval+" %");

        if(floatval == end){
            context.startActivity(new Intent(context, HomeActivity.class));
        }

    }
}
