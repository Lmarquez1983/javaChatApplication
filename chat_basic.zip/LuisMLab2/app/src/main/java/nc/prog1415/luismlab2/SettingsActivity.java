package nc.prog1415.luismlab2;

import static nc.prog1415.luismlab2.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class SettingsActivity extends AppCompatActivity {
    public TextView playerName;
    SeekBar seekbar;
    TextView textView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_settings);
        playerName = findViewById(R.id.playerName);

        String playName = getIntent().getStringExtra("keyname");
        playerName.setText(playName);

        seekbar = (SeekBar) findViewById(id.seekBar);
        textView = (TextView) findViewById(id.volumetxt);

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                textView.setText("Volume " + String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }

    public void onDisplay3(View view){
        switch (view.getId()){
            case id.aboutUsPanel:
                startActivity(new Intent(SettingsActivity.this,AboutActivity.class));
                finish();
        }

    }

    public void backButton(View view){
        switch (view.getId()){
            case id.settingsBackButton:
                startActivity(new Intent(SettingsActivity.this,HomeActivity.class));
                finish();
        }
    }


}