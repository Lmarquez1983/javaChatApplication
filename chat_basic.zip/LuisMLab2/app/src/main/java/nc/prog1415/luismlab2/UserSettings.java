package nc.prog1415.luismlab2;

import android.app.Application;

public class UserSettings extends Application {

    public static final String NIGHTMODE = "nightMode";
    public static final String NOTIFICATIONS = "notifications";
    public static final String PRIVATEACCT = "privateaact";
    public static final String VOLUME = "volume";

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



}
